import fw from "../../fw/index";
import Login from "./login/login";
import Test from "./test";
import {Game} from "./react-tutorial-test/game";
fw.makeStyles({
  ".approot": {
    width: "100vw",
    height: "100vh",
    top: 0,
    left: 0,
    margin: "0px",
    position:"absolute",
    color:"black"
  }
});
export default function App() {
  return (
    <div className="approot">
      <Login></Login>
      <Game></Game>
    </div >
  )
}